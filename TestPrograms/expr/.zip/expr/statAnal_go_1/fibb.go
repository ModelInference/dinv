
var

func main(argc int, argv char**){
	if (argc != 2){
		exit(0)


